package com.bytecode.fourwheeler.impl;

public class InnovaToyota {

}
