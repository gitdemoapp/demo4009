package com.bytecode.fourwheeler.impl;

import com.bytecode.entity.Car;
import com.bytecode.impl.FourWheeler;
import com.bytecode.interf.Vehicle;

public class MarutiSuzukiAlto extends FourWheeler {

	private Car c1 = null;

	public MarutiSuzukiAlto(Car c1) {
		super(c1);
		this.c1 = c1;
	}

	@Override
	public int getNumberOfAirBags() {

		return c1.getNumberOfAirBags();
	}

	@Override
	public int getNumberOfSeats() {

		return c1.getNoOfSeats();
	}

	@Override
	public int engineCapacity() {

		return c1.getEngineCapacity();
	}

	@Override
	public int engineNumber() {

		return c1.getEngineNumber();
	}

	@Override
	public String typesOfFuel() {
		
		return c1.getFuelType();
	}

	@Override
	public Vehicle getVehicleDetails() {
		
		FourWheeler  f=new MarutiSuzukiAlto(c1);
		
		return f;
	}

}
