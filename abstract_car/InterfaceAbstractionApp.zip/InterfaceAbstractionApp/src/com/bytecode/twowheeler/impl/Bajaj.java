package com.bytecode.twowheeler.impl;

public class Bajaj {

}
