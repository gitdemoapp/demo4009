package com.bytecode.twowheeler.impl;

public class Hero {

}
