package com.bytecode.impl;

import com.bytecode.entity.Bike;
import com.bytecode.interf.Vehicle;

public abstract  class TwoWheeler implements Vehicle{

	static Bike bike=null;
	static{
		bike=new Bike();
	}
	@Override
	public int getNumberOfWheels() {
		
		return bike.getNumberOfWheels();
	}

	@Override
	public int getNumberOfAirBags() {
		
		return bike.getNumberOfAirBags();
	}

	@Override
	public int getNumberOfSeats() {
		
		return bike.getNumberOfSeats();
	}

	

}
