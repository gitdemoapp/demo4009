package com.bytecode.impl;

import com.bytecode.entity.Car;
import com.bytecode.interf.Vehicle;

public abstract class FourWheeler implements Vehicle {
	
	private Car c1=null;
	
	public FourWheeler(Car  c1){
		 this.c1=c1;
		 System.out.println("1 param constructor");
	}
	
	public FourWheeler(){
		System.out.println("0 param constructor");
	}
	
	@Override
	public int getNumberOfWheels() {

		return c1.getNumberOfWheels();
	}

	

}
