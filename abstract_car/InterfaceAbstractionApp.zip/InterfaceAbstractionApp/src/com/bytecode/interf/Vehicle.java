package com.bytecode.interf;

public interface Vehicle {
      public abstract int  getNumberOfWheels();
      public abstract int getNumberOfAirBags();
      public abstract int getNumberOfSeats();
      public abstract int engineCapacity();
      public abstract int engineNumber();
      public abstract String typesOfFuel();
      public abstract Vehicle getVehicleDetails();
}
