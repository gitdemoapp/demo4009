package com.bytecode.entity;

public class Bike {
	private String bikeName;
	private int numberOfWheels;
	private int numberOfSeats;
	private int numberOfAirBags;

	public String getBikeName() {
		return bikeName;
	}

	public int getNumberOfWheels() {
		return numberOfWheels;
	}

	public void setBikeName(String bikeName) {
		this.bikeName = bikeName;
	}

	public void setNumberOfWheels(int numberOfWheels) {
		this.numberOfWheels = numberOfWheels;
	}

	public int getNumberOfSeats() {
		return numberOfSeats;
	}

	public void setNumberOfSeats(int numberOfSeats) {
		this.numberOfSeats = numberOfSeats;
	}

	public int getNumberOfAirBags() {
		return numberOfAirBags;
	}

	public void setNumberOfAirBags(int numberOfAirBags) {
		this.numberOfAirBags = numberOfAirBags;
	}

	
}
