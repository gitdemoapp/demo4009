package com.bytecode.entity;

public class Car {
	private String carName;
	private int numberOfWheels;
	private int engineNumber;
	private String fuelType;
	private int noOfSeats;
	private int carId;
	private int numberOfAirBags;
	private int engineCapacity;

	public int getNoOfSeats() {
		return noOfSeats;
	}

	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}

	

	public String getCarName() {
		return carName;
	}

	public int getNumberOfWheels() {
		return numberOfWheels;
	}

	public void setCarName(String carName) {
		this.carName = carName;
	}

	public void setNumberOfWheels(int numberOfWheels) {
		this.numberOfWheels = numberOfWheels;
	}

	public int getEngineNumber() {
		return engineNumber;
	}

	public void setEngineNumber(int engineNumber) {
		this.engineNumber = engineNumber;
	}

	public String getFuelType() {
		return fuelType;
	}

	public int getCarId() {
		return carId;
	}

	public int getNumberOfAirBags() {
		return numberOfAirBags;
	}

	public void setFuelType(String fuelType) {
		this.fuelType = fuelType;
	}

	public void setCarId(int carId) {
		this.carId = carId;
	}

	public void setNumberOfAirBags(int numberOfAirBags) {
		this.numberOfAirBags = numberOfAirBags;
	}

	public int getEngineCapacity() {
		return engineCapacity;
	}

	public void setEngineCapacity(int engineCapacity) {
		this.engineCapacity = engineCapacity;
	}

}
