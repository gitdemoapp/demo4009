package com.bytecode.mainapp;

import com.bytecode.entity.Car;
import com.bytecode.fourwheeler.impl.MarutiSuzukiAlto;
import com.bytecode.interf.Vehicle;

public class App {

	/*
	 * private String carName; private int numberOfWheels; private int engineNumber;
	 * private String fuelType; private int noOfSeats; private int carId; private
	 * int numberOfAirBags; private int engineCapacity;
	 */

	public static void main(String[] args) {
		Car c1 = new Car();
		
		
		c1.setCarName("Alto");
		c1.setCarId(111);
		c1.setNumberOfWheels(4);
		c1.setEngineCapacity(850);
		c1.setEngineNumber(123456789);
		c1.setFuelType("Petrol");
		c1.setNumberOfAirBags(2);
		c1.setNoOfSeats(5);

		MarutiSuzukiAlto msa = new MarutiSuzukiAlto(c1);
		int totalAirBags = msa.getNumberOfAirBags();
		System.out.println(totalAirBags);

		Vehicle v1 = msa.getVehicleDetails();
		System.out.println(v1.getNumberOfSeats());
		System.out.println(v1.typesOfFuel());
		
		System.out.println(v1.getNumberOfWheels());

	}

}
