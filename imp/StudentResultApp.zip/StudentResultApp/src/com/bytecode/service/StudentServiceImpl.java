package com.bytecode.service;

import com.bytecode.bo.StudentBO;
import com.bytecode.dao.StudentDao;
import com.bytecode.dao.StudentDaoImpl;
import com.bytecode.dto.StudentDTO;

public class StudentServiceImpl implements StudentService {

	@Override
	public String calculateResult(StudentDTO dto) {
		// defining all local variables
		int rno = 0;
		String name = null;
		int m1, m2, m3, m4, m5;
		double total = 0.0;
		double avg = 0.0;
		String result = null;
		StudentBO bo = null;
		StudentDao dao=null;
		String data=null;
		// get data from dto object
		rno = dto.getRno();
		name = dto.getName();
		m1 = dto.getM1();
		m2 = dto.getM2();
		m3 = dto.getM3();
		m4 = dto.getM4();
		m5 = dto.getM5();

		// perform business logic

		total = m1 + m2 + m3 + m4 + m5;

		// find avg

		avg = total / 5;

		if (avg < 33) {
			result = "fail";
		} else {
			result = "pass";
		}

		// set business data to bo object

		bo = new StudentBO();
		bo.setRno(rno);
		bo.setName(name);
		bo.setTotal(total);
		bo.setAvg(avg);
		bo.setResult(result);
		
		dao=new StudentDaoImpl();
		data=dao.insertStudentResult(bo);
		return data;
	}

}
