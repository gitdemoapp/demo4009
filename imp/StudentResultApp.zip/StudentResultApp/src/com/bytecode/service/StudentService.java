package com.bytecode.service;

import com.bytecode.dto.StudentDTO;

public interface StudentService {
     public abstract String calculateResult(StudentDTO dto);
     
}
