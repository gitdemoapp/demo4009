package com.bytecode.dao;

import com.bytecode.bo.StudentBO;

public interface StudentDao {
	public abstract String insertStudentResult(StudentBO bo);
}
