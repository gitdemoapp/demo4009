package com.bytecode.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.bytecode.bo.StudentBO;

public class StudentDaoImpl implements StudentDao {

	@Override
	public String insertStudentResult(StudentBO bo) {
		Connection con = null;
		String INSERT_STUDENT_RESULT = null;
		PreparedStatement ps = null;
		int count=0;
		String data=null;
		// load the driver class
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			// create the COnnection object
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "bytecode1", "bytecode1");
			// create sql query
			INSERT_STUDENT_RESULT = "insert into student_result values(?,?,?,?,?)";

			// create PreparedStatement object\
			if (con != null) {
				ps = con.prepareStatement(INSERT_STUDENT_RESULT);
			}
			// set values to Pre compiled sql query
			if (ps != null) {
				ps.setInt(1, bo.getRno());
				ps.setString(2, bo.getName());
				ps.setDouble(3, bo.getTotal());
				ps.setDouble(4, bo.getAvg());
				ps.setString(5, bo.getResult());
				
				 //execute the query
				count=ps.executeUpdate();
			}
			
			if(count==0) {
				data="Student data not inserted";
			}
			else {
				data="Student data  inserted";
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return data;
	}

}
