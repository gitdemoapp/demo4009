package com.bytecode.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bytecode.dto.StudentDTO;
import com.bytecode.service.StudentService;
import com.bytecode.service.StudentServiceImpl;
import com.bytecode.vo.StudentVO;

public class StudentController extends HttpServlet {
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// define all local variables at top
		PrintWriter pw = null;
		String rno, name, m1, m2, m3, m4, m5;
		StudentVO vo = null;
		StudentDTO dto = null;
		StudentService  service=null;
		// set content type
		resp.setContentType("text/html");

		// get PrintWriter object

		pw = resp.getWriter();

		// read request data

		rno = req.getParameter("rno");
		name = req.getParameter("name");
		m1 = req.getParameter("m1");
		m2 = req.getParameter("m2");
		m3 = req.getParameter("m3");
		m4 = req.getParameter("m4");
		m5 = req.getParameter("m5");

		// create StudentVo object and set data to vo object

		vo = new StudentVO();
		vo.setRno(rno);
		vo.setName(name);
		vo.setM1(m1);
		vo.setM2(m2);
		vo.setM3(m3);
		vo.setM4(m4);
		vo.setM5(m5);

		// convert vo class object into DTO class object

		dto = new StudentDTO();
		dto.setRno(Integer.parseInt(vo.getRno()));
		dto.setName(vo.getName());
		dto.setM1(Integer.parseInt(vo.getM1()));
		dto.setM2(Integer.parseInt(vo.getM2()));
		dto.setM3(Integer.parseInt(vo.getM3()));
		dto.setM4(Integer.parseInt(vo.getM4()));
		dto.setM5(Integer.parseInt(vo.getM5()));
		
		service=new StudentServiceImpl();
		
		String data=service.calculateResult(dto);
		
		pw.println("<h1>" + data+"</h1>");

	}

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
