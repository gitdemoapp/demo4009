package com.bytecode.springboot;

public class FootballCoach implements Coach {
	public String getDailyWorkout() {
		return " Football please run 10 km daily";
	}
}
