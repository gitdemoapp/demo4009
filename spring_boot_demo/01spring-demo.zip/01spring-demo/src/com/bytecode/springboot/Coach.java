package com.bytecode.springboot;

public interface Coach {
   public String getDailyWorkout();
}
