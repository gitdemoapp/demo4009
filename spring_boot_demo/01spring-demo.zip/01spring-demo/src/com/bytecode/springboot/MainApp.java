package com.bytecode.springboot;

public class MainApp {

	public static void main(String[] args) {
		
		//CricketCoach coach = new CricketCoach();
		
		//Coach  coach= new CricketCoach();
		
		/*String msg=coach.getDailyWorkout();
		
		System.out.println(msg);
*/		
	}

}
