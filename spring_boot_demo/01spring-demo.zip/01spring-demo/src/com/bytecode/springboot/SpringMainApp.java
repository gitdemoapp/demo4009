package com.bytecode.springboot;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringMainApp {

	public static void main(String[] args) {
		//create spring container and load the spring configuration file
		ClassPathXmlApplicationContext context=new ClassPathXmlApplicationContext("applicationContext.xml");
		// retrieve bean object from spring container
		Coach coach=context.getBean("ccoach",Coach.class);
		//call the methods
		 System.out.println(coach.getDailyWorkout() );
		//close the context
		 context.close();

	}

}
