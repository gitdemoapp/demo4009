package com.bytecode.springboot;

public class TennisCoach implements Coach {

	@Override
	public String getDailyWorkout() {
		
		return "Tennis Coach --->practice 5 hours daily";
	}

}
