package com.bytecode.springboot;

public class CricketCoach  implements Coach{

     public String getDailyWorkout() {
    	 return "Cricket practice daily for 2 hours";
     }
}
