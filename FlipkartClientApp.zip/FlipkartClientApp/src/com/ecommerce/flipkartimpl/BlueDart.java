package com.ecommerce.flipkartimpl;

import com.ecommerce.customer.Customer;
import com.ecommerce.flipkart.Flipkart;

public  class BlueDart implements Flipkart{

	@Override
	public boolean delivery(Customer obj, String productName) {
		
		System.out.println(productName +" delivered to "+obj.getCustomerName());
		
		return true;
	}
}
