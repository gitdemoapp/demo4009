package com.ecommerce.app;

import java.util.Scanner;

import com.ecommerce.customer.Customer;
import com.ecommerce.flipkart.Flipkart;
import com.ecommerce.implfactory.ImplFactory;

public class ClientApp {

	public static void main(String[] args) {
		
		Customer obj1=new Customer("Raja", "Kanpur", 112233L, "raja@gmail.com");
		Customer obj2=new Customer("Rani", "Lko", 112244L, "rani@gmail.com");
		
				
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter company name");
		
		String impObject =scanner.next();
		
        System.out.println("Enter product name");
		
		String p1 =scanner.next();

		Flipkart flipkart = ImplFactory.getFlipkartImplClassObject(impObject);
		
		boolean b=flipkart.delivery(obj1, p1);
		
		if(b==true) {
		flipkart.service_installation();
		}
		else {
			System.out.println("installation not completed ");
			System.out.println("Send engineer for insdtallation !!!");
		}
		
		 obj1.viewProfile();
		 obj2.viewProfile();
	}
}
