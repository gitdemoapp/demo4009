package com.ecommerce.customer;

public class Customer {

	private String customerName;
	private String customerAddress;
	private long customerContactNumber;
	private String customerEmailID;

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public long getCustomerContactNumber() {
		return customerContactNumber;
	}

	public void setCustomerContactNumber(long customerContactNumber) {
		this.customerContactNumber = customerContactNumber;
	}

	public String getCustomerEmailID() {
		return customerEmailID;
	}

	public void setCustomerEmailID(String customerEmailID) {
		this.customerEmailID = customerEmailID;
	}

	
	public Customer(String customerName, String customerAddress, long customerContactNumber, String customerEmailID) {
		
		this.customerName = customerName;
		this.customerAddress = customerAddress;
		this.customerContactNumber = customerContactNumber;
		this.customerEmailID = customerEmailID;
	}

	
	public void viewProfile() {
		System.out.println( "Customer [customerName=" + customerName + ", customerAddress=" + customerAddress
				+ ", customerContactNumber=" + customerContactNumber + ", customerEmailID=" + customerEmailID + "]");
	}
	
}
