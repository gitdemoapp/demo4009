package com.ecommerce.flipkart;

import com.ecommerce.customer.Customer;

public interface Flipkart {

	
	public abstract boolean delivery(Customer obj, String productName);

	default boolean service_installation() {
		boolean flag = false;
		System.out.println("Intallation completed  , thanks for shopping  , for any queries please contact to "+Company.companyTollFreeNumber);
		flag = true;
		return flag;
	}
}
