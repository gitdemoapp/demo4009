package com.ecommerce.flipkart;

public class Company {
    public static final long companyTollFreeNumber=1800100222L;
    
   public static final String companyName="Flipkart";
}
