package com.ecommerce.flipkart.productimpl;

import com.ecommerce.flipkart.Flipkart;

public abstract class LG implements Flipkart{

	@Override
	public boolean service_installation() {
		
		return false;
	}
}
