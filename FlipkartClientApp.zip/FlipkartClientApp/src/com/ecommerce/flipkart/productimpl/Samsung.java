package com.ecommerce.flipkart.productimpl;

import com.ecommerce.flipkart.Flipkart;

public abstract class Samsung implements Flipkart {


	@Override
	public boolean service_installation() {
		
		return false;
	}

}
