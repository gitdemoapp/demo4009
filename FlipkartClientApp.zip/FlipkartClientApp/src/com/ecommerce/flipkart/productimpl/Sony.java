package com.ecommerce.flipkart.productimpl;

import com.ecommerce.flipkart.Flipkart;

public abstract class Sony implements Flipkart{

	@Override
	public boolean service_installation() {
		
		return false;
	}

}
