package com.ecommerce.implfactory;

import com.ecommerce.flipkart.Flipkart;

import com.ecommerce.flipkartimpl.BlueDart;
import com.ecommerce.flipkartimpl.Delihvery;
import com.ecommerce.flipkartimpl.Ekart;

public class ImplFactory {

	public static Flipkart getFlipkartImplClassObject(String implObjectName) {

		if (implObjectName.equalsIgnoreCase("bluedart")) {
			return new BlueDart();
		}

		else if (implObjectName.equalsIgnoreCase("ekart")) {
			return new Ekart();
		}

		else if (implObjectName.equalsIgnoreCase("delihvery")) {
			return new Delihvery();
		} else {

			return null;
		}

	}
}
