package com.bytecode.servlet.dao;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class EmployeeApp extends HttpServlet {

	PrintWriter printWriter = null;
	String empNumber = null;
	ResultSet resultSet = null;
	Connection connection = null;
	PreparedStatement preparedStatement = null;

	@Override
	public void init() throws ServletException {

		String GET_EMP_BY_ID = null;
		// load the driver
		try {
			System.out.println("before loading the driver");
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("after loading the driver");

			// create the Connection

			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe",
					"empapp", "emp123");

			// prepare sql query
			GET_EMP_BY_ID = "select * from employee where id=?";

			preparedStatement = connection.prepareStatement(GET_EMP_BY_ID);

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}// init()

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		int eno = 0;
		// set content type
		resp.setContentType("text/html");
		// get PrintWriter object
		printWriter = resp.getWriter();

		// read form data
		empNumber = req.getParameter("empno");
		eno = Integer.parseInt(empNumber);

		// set input values to pre compiled sql query
		if (preparedStatement != null) {
			try {
				preparedStatement.setInt(1, eno);
				// execute sql query and fetch the records
				System.out.println("before");
				resultSet = preparedStatement.executeQuery();
				System.out.println("after");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} // if

		if (resultSet != null) {
			try {
				if (resultSet.next() != false) {
					int employeeId = resultSet.getInt(1);
					String name = resultSet.getString(2);
					int salary = resultSet.getInt(3);
					String department = resultSet.getString(4);
					System.out.println("Hello");
					printWriter.println("<h3> Employee Id :: " + employeeId + "</h3>");
					printWriter.println("<h3> Employee Name :: " + name + "</h3>");
					printWriter.println("<h3> Employee Salary :: " + salary + "</h3>");
					printWriter.println("<h3> Employee Dept :: " + department + "</h3>");

				}
				printWriter.println("<h3> <a href ='index.html'> back to home </a></h3>");
			} catch (SQLException e) {

				e.printStackTrace();
			} catch (Exception e) {

				e.printStackTrace();
			}
		}

	}// doPost

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}

	// override destroy method
	@Override
	public void destroy() {
		try {
			resultSet.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			printWriter.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}// destroy

}// class
