package com.vsics.student.result.exception;

public class InvalidOptionException extends RuntimeException {
     	public InvalidOptionException(String msg) {
     		super(msg);
     	}
}
