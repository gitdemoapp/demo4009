package com.bytecode.ps.example;

import java.io.File;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.Reader;
import java.nio.CharBuffer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class FetchPSResumeApp {

	public static final String url = "jdbc:oracle:thin:@localhost:1521:xe";
	public static final String user = "bytecode1";
	public static final String password = "bytecode1";

	public static void main(String[] args) {

		// defining all variables
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		String SELECT_ADMIN_DETAILS_BY_ID = "select * from admin1 where aid=?";
		// int customerID = 0;
		Scanner scanner = null;
		String adminName = null;
		int adminSal = 0;
		ResultSet resultSet = null;
		File file = null;
		String filePath = null;
		int adminID = 0;
		int id = 0;
		String name = null;
		int sal = 0;
		Reader reader = null;
		FileWriter fileWriter = null;
		// load the driver class

		try {
			file = new File("D:\\retrieve2.txt");
			fileWriter = new FileWriter(file);

			scanner = new Scanner(System.in);

			System.out.println("Please enter admin id to get details from db");

			adminID = scanner.nextInt();

			Class.forName("oracle.jdbc.driver.OracleDriver");

			// create Connection object

			connection = DriverManager.getConnection(url, user, password);

			// prepare sql query

			// create Statement object--->now we are going to use PreparedStatement
			if (connection != null) {
				preparedStatement = connection.prepareStatement(SELECT_ADMIN_DETAILS_BY_ID);

			}
			// set values to place holder

			if (preparedStatement != null) {
				preparedStatement.setInt(1, adminID);

				resultSet = preparedStatement.executeQuery();
			}

			if (resultSet != null) {
				if (resultSet.next() != false) {
					id = resultSet.getInt(1);
					name = resultSet.getString(2);
					sal = resultSet.getInt(3);
					reader = resultSet.getCharacterStream(4);
				   
				}
			}

			int bytesRead = 0;

			char[] buffer = new char[1024];

			while ((bytesRead = reader.read(buffer)) != -1) {
				fileWriter.write(buffer, 0, bytesRead);
			}
			
			System.out.println("id:: "+id);
			System.out.println("name:: "+name);
			System.out.println("salary:: "+sal);
			
			// Handling known exception
		} catch (ClassNotFoundException | SQLException e) {

			e.printStackTrace();
		}
		// handling unknown exception
		catch (Exception e) {
			e.printStackTrace();
		}

		// close all connections in reverse order

		finally {
			try {
				if (preparedStatement != null) {
					preparedStatement.close();
				}
			} catch (SQLException e) {

				e.printStackTrace();
			}

			try {
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {

				e.printStackTrace();
			}

			try {
				if (scanner != null) {
					scanner.close();
				}
			} catch (Exception e) {

				e.printStackTrace();
			}
			
			try {
				if (reader != null) {
					reader.close();
				}
			} catch (Exception e) {

				e.printStackTrace();
			}
			
			try {
				if (fileWriter != null) {
					fileWriter.close();
				}
			} catch (Exception e) {

				e.printStackTrace();
			}

		} // finally

	}// main

}// class
